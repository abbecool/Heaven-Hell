HeavenHell-0.7.0-linux-x86_64

Run ./play.sh to start the game.

This package targets the build machine's CPU architecture.
Use the same Linux distribution/version or a compatible newer system.
The host must provide glibc, a graphical session, and OpenGL drivers.
Linked dependencies are bundled; dynamically loaded plugins may still
require host packages. This is not a universal Linux/AppImage build.
